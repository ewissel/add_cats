import add_cats

meow = add_cats_ewissel.get_cat(cat_type = "big")

print(meow)
