from add_cats import get_cat

meow_meow = get_cat(cat_type = "sad")

print(meow_meow)
