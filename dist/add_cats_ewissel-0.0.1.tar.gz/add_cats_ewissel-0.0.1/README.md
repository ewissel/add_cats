# add_cats Package

This is a package written to easily add ASCII art cats to printed messages in python. Creating a repo by popular demand (one person asked)

Currently this package requires python3, not out of neccessity, but to encourage best practices with my coworkers. It is time to release python2 to the past. You may need to run `python3 -m pip install --upgrade pip` (unix) or `py -m pip install --upgrade pip` (windows) as well when installing this package. 

This package follows a standard MIT license, meaining you can do what you want with this, but you can'd hold me liable for the ASCII cat usage [:)](https://www.tldrlegal.com/license/mit-license)

To make this pip installable, I am following the following tutorial: [Packaging Python Projects from packaging.python.org](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
